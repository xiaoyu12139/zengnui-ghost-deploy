# Members

This is an awesome features of Ghost. If you want to make money with publications, you can use Membership features of Ghost.

## Portal

Go in your Ghost's `dashboard -> Settings -> Membership -> Portal Settings`

By default, Simply uses Portal for member management. If you prefer, Simply also comes with individual pages to support the membership function.

> If you want to use with individual pages let me know. I will create a more functional version.

## Disable Membership

Many people have been asking me to disable membership.

You will now be able to disable the login buttons and forms.

➡️ `Dashboard -> Settings -> Membership -> Subscription access -> Nobody`

![disable-member](https://user-images.githubusercontent.com/10253167/172016685-2c87a5ad-3db2-4972-bddb-7fbba10c8ae6.jpg)

